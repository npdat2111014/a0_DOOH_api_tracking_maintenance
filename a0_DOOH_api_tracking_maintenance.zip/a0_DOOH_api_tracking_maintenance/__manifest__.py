{
    'name': " DOOH API TRACKING MAINTENANCE module ",
    'summary': """DOOH Api module for tracking maintenance""",
    'description': """This is a module used for customers to upload their notification about how their devices are""",
    'author': "Phước Đạt Nguyễn",
    'category': 'Uncategorized',
    'version': '0.0',
    'depends': [
        'base','website', 'mail'
    ],
    'data': [
        'views/api_tracking_maintenance_web.xml',
        'views/api_tracking_maintenance_main_menu.xml',
        'views/api_tracking_maintenance_views.xml',
        'views/api_tracking_maintenance_container_views.xml',
        'views/api_tracking_maintenance_zip_views.xml',
        'views/api_tracking_maintenance_mail_views.xml',
        'views/api_tracking_maintenance_telegram_views.xml',
        'views/api_tracking_maintenance_search_views.xml',
        'views/upload_success.xml',
        'views/images_views.xml',
        # 'views/email_template.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
    ],
    'assets': {
        'web.assets_backend': [
            'a0_DOOH_api_tracking_maintenance/static/src/img/vector.svg',
            'a0_DOOH_api_tracking_maintenance/static/src/css/api_tracking_maintenance_custom.css',
            'a0_DOOH_api_tracking_maintenance/static/src/img/nature.png',
            'a0_DOOH_api_tracking_maintenance/static/src/img/vector.svg',
        ],
        'web.assets_frontend':[
            'a0_DOOH_api_tracking_maintenance/static/src/css/api_tracking_maintenance_web.css',
            'a0_DOOH_api_tracking_maintenance/static/src/js/api_tracking_maintenance_web.js',
        ]
    },
    'installable': True,
    'application': True,
}