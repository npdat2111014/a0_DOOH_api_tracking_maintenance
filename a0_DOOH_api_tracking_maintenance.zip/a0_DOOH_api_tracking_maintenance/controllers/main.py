import os
from werkzeug.datastructures import FileStorage
from odoo import http, api, SUPERUSER_ID, registry as registry_get
from odoo.http import request
import base64
import zipfile
from io import BytesIO
from odoo.modules import get_module_path
from datetime import datetime


class MyMaintenance(http.Controller):
    _inherit = 'mail.mail'
    _key_value = None
    _current_url = None
    _store_name = None

    @http.route('/api/tracking_maintenance', auth='public', methods=['GET'], website=True, csrf=False, type='http')
    def func_api_maintenance(self, **get):
        key = get.get('key')
        title = get.get('title')
        store = get.get('store')
        store1 = get.get('store1')

        self._title_value = title
        self._key_value = key
        self._current_url = request.httprequest.url
        print(self._current_url)

        # self.demo()
        return http.request.render('a0_DOOH_api_tracking_maintenance.api_tracking_maintenance_custom_report_template',
                                   {'key_value': key, 'title_value': title, 'store_value': store,
                                    'store1_value': store1})

    # def btn_save ban đầu
    @http.route('/btn_save', type='http', auth='public', website=True, csrf=False)
    def btn_save(self, **post):
        storeChain = post.get('storeChain')
        storeID = post.get('storeID')
        description = post.get('description')
        images = request.httprequest.files.getlist('image')
        if not storeID:
            return "error"
        if len(images) > 200:
            return "error"

        valid_images = []
        for image in images:
            if isinstance(image, FileStorage):
                mimetype = image.mimetype
                # print(image.mimetype)
                if mimetype != 'application/octet-stream':
                    valid_images.append(image)

        if len(valid_images) == 0:
            Maintenance = request.env['a0.api.tracking.maintenance.table']

            # Create a new maintenance record
            record = Maintenance.sudo().create({
                'storeChain': self._key_value,
                'storeID': storeID,
                'description': description,
                'reportedDate': datetime.now(),
                'numberOfImage': 0,
            })
            # return Response(f"Images uploaded successfully", status=200)
            return request.redirect('/success_page')

        try:
            Maintenance = request.env['a0.api.tracking.maintenance.table']
            Container = request.env['a0.api.tracking.maintenance.container.table']

            # Create a new maintenance record
            record = Maintenance.sudo().create({
                'storeChain': self._key_value,
                'storeID': storeID,
                'description': description
            })

            image_ids = []
            for image in images:
                # image_name = image.filename
                # print(image.mimetype)
                image_data = base64.b64encode(image.read())
                mime_to_extension = {
                    'image/jpeg': 'jpg',
                    'image/png': 'png',
                    'image/gif': 'gif',
                    'image/bmp': 'bmp',
                    'image/tiff': 'tiff',
                    'image/webp': 'webp',
                    'image/svg+xml': 'svg',
                    'image/x-icon': 'ico'
                }
                attachment = Container.sudo().create({
                    # 'name': image_name,
                    'imageDisplay': image_data,
                    'my_model_id': record.id,
                    'imageType': mime_to_extension.get(image.mimetype, '')
                })
                image_ids.append(attachment.id)

            # Update the image_display field of the maintenance record with the created image ids
            record.sudo().write({
                'imageDisplay': [(6, 0, image_ids)],
                'reportedDate': datetime.now(),
                'numberOfImage': len(images)
            })
            return request.redirect('/success_page')
            # return Response(f"Images uploaded successfully, Maintenance ID: {record.id}", status=200)
        except Exception as e:
            # Log the error for debugging purposes
            print(f'Error occurred: {e}')
            # Return an error response
            return http.Response('An error occurred', status=500)

    @http.route('/success_page', type='http', auth='public', website=True, csrf=False)
    def success_page(self, **get):
        return http.request.render('a0_DOOH_api_tracking_maintenance.success_page', {'current_url': self._current_url})

    @http.route('/web/binary/download_images', type='http', auth='user')
    def save_image_to_path(self, model, ids):
        ids = [int(id) for id in ids.split(',')]
        records = request.env[model].browse(ids)

        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
            for record in records:
                for container in record.imageDisplay:
                    if container.imageDisplay:
                        image_data = base64.b64decode(container.imageDisplay)
                        mimetype = container.imageType.replace('image/', '')
                        zip_file.writestr(f'{record.storeID}_{container.id}.{mimetype}', image_data)
        # Get the absolute path of the module
        module_path = get_module_path('a0_DOOH_api_tracking_maintenance')
        save_path = os.path.join(module_path, 'static/src/img/zip_file/')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        # Generate a unique filename if the file already exists
        base_filename = "images"
        extension = ".zip"
        file_path = os.path.join(save_path, base_filename + extension)

        if os.path.exists(file_path):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = os.path.join(save_path, f"{base_filename}_{timestamp}{extension}")
        with open(file_path, 'wb') as file:
            file.write(zip_buffer.getvalue())

    @http.route('/images', auth='public', methods=['GET'], website=True, csrf=False, type='http')
    def show_image(self, **get):
        imageID = get.get('imageID')
        image_records = request.env['a0.api.tracking.maintenance.table'].sudo().search([('id', '=', int(imageID))])

        if not image_records:
            return "No images found for this record."

        images_data = []
        for image_record in image_records:
            for image in image_record.imageDisplay:
                if image.imageDisplay:
                    image_data = image.imageDisplay.decode('utf-8')
                    mimetype = image.imageType.replace('image/', '')
                    images_data.append({"dataImage": image_data, "dataType": mimetype})
        return http.request.render('a0_DOOH_api_tracking_maintenance.images', {'containImage': images_data})
