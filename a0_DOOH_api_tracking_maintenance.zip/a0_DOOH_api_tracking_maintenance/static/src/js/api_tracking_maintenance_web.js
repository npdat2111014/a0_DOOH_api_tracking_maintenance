// custom_script.js
src="https://code.jquery.com/jquery-3.6.0.min.js"
src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"
document.addEventListener('DOMContentLoaded', function() {
    // Image preview on file input change
    document.getElementById('file-input').addEventListener('change', function(event) {
        const files = event.target.files;
        const preview = document.getElementById('image-preview');
        preview.innerHTML = ''; // Clear the current preview
        let fileList = []; // Initialize file list

        Array.from(files).forEach((file, index) => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const imgContainer = document.createElement('div');
                    imgContainer.className = 'image-container';

                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'preview-image';
                    imgContainer.appendChild(img);

                    preview.appendChild(imgContainer);
                    fileList.push(file); // Add file to file list

                    // Add click event to image for zoom
                    img.addEventListener('click', function() {
                        const modal = document.getElementById('imageModal');
                        const modalImg = document.getElementById('img01');
                        modal.style.display = "block";
                        modalImg.src = this.src;
                    });
                };
                reader.readAsDataURL(file);
            }
        });
    });

    document.getElementById('submit-button').addEventListener('click', function(event) {
        var storeID = document.getElementById('storeID').value;
        var fileCount = document.getElementById('file-input').files.length;

        if (!storeID) {
            event.preventDefault(); // Ngăn chặn gửi form
            alert("Please fill in the storeID field.");
        } else if (fileCount > 200) {
            event.preventDefault(); // Ngăn chặn gửi form
            alert("You can only upload a maximum of 200 images.");
        }
//        else {
//            var description = $("#description").val();
//            var formData = new FormData();
//            formData.append('storeID', storeID);
//            formData.append('description', description);
//
//            for (var i = 0; i < fileCount; i++) {
//                formData.append('images[]', files[i]);
//            }
//            $.ajax({
//                type: 'POST',
//                url: "/btn_save",
//                data: formData,
//                processData: false,
//                contentType: false,
//                beforeSend: function() {
//                    $("#submit-button, #cancel-button").prop("disabled", true);
//                    $("#loader").show();
//                },
//                success: function(response) {
//                    // Xử lý khi nhận được phản hồi từ server (nếu cần)
//                    console.log(response);
//                },
//                error: function(xhr, status, error) {
//                    // Xử lý khi có lỗi trong quá trình gửi request
//                    console.error(xhr.responseText);
//                },
//                complete: function() {
//                    $("#submit-button, #cancel-button").prop("disabled", false);
//                    $("#loader").hide();
//                },
//            });
//        }
    });


//    // Form submission validation for storeID field
//    document.getElementById('submit-button').addEventListener('click', function(event) {
//        var storeID = document.getElementById('storeID').value;
//        if (!storeID) {
//            event.preventDefault(); // Prevent form submission
//            alert("Please fill in the storeID field.");
//        }
//    });

    // Modal close functionality
    const closeModal = document.getElementById('closeModal');
    if (closeModal) {
        closeModal.onclick = function() {
            const modal = document.getElementById('imageModal');
            modal.style.display = "none";
        };
    }


//    // jQuery AJAX setup
//    $("#submit-button").on("click", function() {
//        var storeID = $("#storeID").val();
//        var description = $("#description").val();
//        var fileCount = document.getElementById('file-input').files.length;
//        var formData = new FormData();
//        formData.append('storeID', storeID);
//        formData.append('fileCount', fileCount);
//        formData.append('description', description);
//
//        $.ajax({
//            type: 'POST',
//            url: "/btn_save",
//            data: formData,
//            processData: false,
//            contentType: false,
//            beforeSend: function() {
//                $("#submit-button, #cancel-button").prop("disabled", true);
//                $("#loader").show();
//            },
//            complete: function() {
//                $("#submit-button, #cancel-button").prop("disabled", false);
//                $("#loader").hide();
//            },
////            success: function(response) {
////                console.log(response);  // Handle success response
////                // Example: Display success message or redirect
////            },
////            error: function(xhr, status, error) {
////                console.error(xhr.responseText);  // Handle error
////            }
//        });
//    });
});





