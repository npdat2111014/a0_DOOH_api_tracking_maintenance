import asyncio
import threading
import time
from odoo.addons.a0_DOOH_api_tracking_maintenance.models.send_api_test import *
from odoo.addons.a0_DOOH_api_tracking_maintenance.models.telegram_send_api import *
from odoo.addons.a0_DOOH_api_tracking_maintenance.models.config import *
from odoo.addons.a0_DOOH_api_tracking_maintenance.models.database import *


def send_email_sub_test():
    query = '''  SELECT DISTINCT "storeChain"
                 FROM %s;
            ''' % "a0_api_tracking_maintenance_table"
    cursor1 = conn.cursor()
    cursor1.execute(query)
    chains = cursor1.fetchall()
    if len(chains) == 0:
        return print("không có cửa hàng")
    for chain in chains:
        if chain[0] is None:
            continue
        query = '''
                    SELECT "id", "storeChain", "mailReceive" FROM %s
                    WHERE UPPER("storeChain") = '%s'
                ''' % ("a0_api_tracking_maintenance_mail_table", chain[0].upper().replace("'", ""))
        cursor2 = conn.cursor()
        cursor2.execute(query)
        receivers = cursor2.fetchall()

        if len(receivers) == 0:
            continue

        query = ''' SELECT "id", "storeChain", "storeID", "description", "numberOfImage" FROM %s
                    WHERE UPPER("storeChain") = '%s' and "mailStatus" = 'not_sent'
                            ''' % ("a0_api_tracking_maintenance_table", chain[0].upper().replace("\'", ""))
        cursor3 = conn.cursor()
        cursor3.execute(query)
        mails = cursor3.fetchall()
        if len(mails) == 0:
            continue

        contain = f"{email_contain['body']}"
        i = 0
        for receiver in receivers:
            for mail in mails:
                i += 1
                if mail[3] is None:
                    description = ""
                else:
                    description = mail[3].rstrip()

                api_send = f'{email_contain["domain"]}{email_contain["endpoint_image"]}?imageID={mail[0]}'

                if int(mail[4]) > 0:
                    contain = f" <br> {contain} {i}) {mail[0]} | {mail[1]} | {mail[2]} | {description}| <a href={api_send}>Link Hình</a>"
                else:
                    contain = f" <br> {contain} {i}) {mail[0]} | {mail[1]} | {mail[2]} | {description}| "
            contain = f"""
                        <html>
                        <head>
                          <style>
                            /* Định dạng CSS cho phần nội dung */
                            .content-box {{
                                border: 2px solid #00CD00;
                                border-radius: 15px;
                                padding: 20px;
                                background-color: #98FB98;
                                max-width: 90%;
                                margin: 20px auto;
                                box-sizing: border-box;
                                opacity: 0.7;
                            }}
                            .info-wrapper {{
                                display: flex;
                                justify-content: space-between;
                                align-items: center;
                                margin-top: 10px;
                                position: relative; /* Để có thể dùng :after */
                            }}
                            .info-wrapper:after {{
                                content: '';
                                position: absolute;
                                left: 0;
                                bottom: -5px; /* Khoảng cách đường kẻ dưới */
                                width: 100%;
                                border-bottom: 1px dashed #006400; /* Đường kẻ đứt ngang */
                            }}
                            .label {{
                                flex: 1;
                                text-align: right;
                                margin-right: 10px;
                                font-weight: bold;
                                color: #006400;
                                font-size: 18px; /* Phóng to chữ */
                                display: inline-block;
                            }}
                            .value {{
                                flex: 2;
                                text-align: left;
                                font-size: 16px; /* Phóng to chữ */
                            }}
                            .image-link {{
                                display: block;
                                margin-top: 10px;
                                color: #007bff;
                                font-size: 16px; /* Phóng to chữ */
                            }}
                            .image-link a {{
                                color: #007bff;
                                text-decoration: none;
                                display: inline-block;
                            }}
                          </style>
                        </head>
                        <body>
                          <div class="content-box">
                            <h2 style="text-align: center; color: #008B00; font-size: 30px;">THÔNG TIN CỬA HÀNG</h2>
                            <h2 style="text-align: center; color: #008B00; font-size: 20px;">-----------------------</h2>
                            <p font-size:25 >{contain}</p>
                          </div>
                        </body>
                        </html>
                        """
            print(contain)

            body_email = {
                'subject': f"[{receiver[1]}] {email_contain['subject']}".upper(),
                'email_from': f"{email_contain['sender_email']}",
                'email_from_pass': f"{email_contain['sender_password']}",
                'email_to': f"{receiver[2]}",
                'body_html': f'{contain}',
            }

            try:
                print(body_email['subject'])
                subject = body_email['subject']
                send_email(body_email['email_from'], body_email['email_from_pass'], body_email['email_to'],
                           subject, body_email['body_html'])
                for mail in mails:
                    query = '''
                        UPDATE %s
                        SET "mailStatus" = '%s'
                        WHERE id = '%s';
                    ''' % ("a0_api_tracking_maintenance_table", "sent", mail[0])
                    # print(query)
                    cursor4 = conn.cursor()
                    cursor4.execute(query)
                    conn.commit()
            except Exception as e:
                print(e)
                return e
            # send_email("dat.nguyen14012003@hcmut.edu.vn", "zibn gvlo svke ysil","phuocdat1401001@gmail.com", "Email báo cáo sự cố của Prowtech", body_email['body_html'])


def send_email_sub():
    query = '''  SELECT DISTINCT "storeChain"
                 FROM %s;
            ''' % "a0_api_tracking_maintenance_table"
    chains = query_fetchall(query, conn)
    if chains == 0:
        return print("Lỗi không lấy được chains")
    if len(chains) == 0:
        return print("không có cửa hàng")
    for chain in chains:
        if chain[0] is None:
            continue
        query = '''
                    SELECT "id", "storeChain", "mailReceive" FROM %s
                    WHERE UPPER("storeChain") = '%s'
                ''' % ("a0_api_tracking_maintenance_mail_table", chain[0].upper().replace("'", ""))
        receivers = query_fetchall(query, conn)
        if receivers == 0:
            continue

        if len(receivers) == 0:
            continue

        query = ''' SELECT "id", "storeChain", "storeID", "description", "numberOfImage" FROM %s
                    WHERE UPPER("storeChain") = '%s' and "mailStatus" = 'not_sent'
                            ''' % ("a0_api_tracking_maintenance_table", chain[0].upper().replace("\'", ""))

        mails = query_fetchall(query, conn)
        if mails == 0:
            continue
        if len(mails) == 0:
            continue

        contain = f"{email_contain['body']}"
        count_email = 0
        for receiver in receivers:
            for mail in mails:
                count_email += 1
                if mail[3] is None:
                    description = ""
                else:
                    description = mail[3].rstrip()

                api_send = f'{email_contain["domain"]}{email_contain["endpoint_image"]}?imageID={mail[0]}'

                if int(mail[4]) > 0:
                    contain = f"{contain} <br>     {count_email}) {mail[0]} | {mail[1]} | {mail[2]} | {description}| <a href={api_send}>Link Hình</a>"
                    print(contain)
                else:
                    contain = f"{contain} <br>     {count_email}) {mail[0]} | {mail[1]} | {mail[2]} | {description}| "
                    print(contain)
            contain = email_carry(contain)
            print(contain)
            if contain == 0:
                continue
            body_email = {
                'subject': f"[{receiver[1]}] {email_contain['subject']}".upper(),
                'email_from': f"{email_contain['sender_email']}",
                'email_from_pass': f"{email_contain['sender_password']}",
                'email_to': f"{receiver[2]}",
                'body_html': f'{contain}',
            }
            try:
                subject = body_email['subject']
                send_email(body_email['email_from'], body_email['email_from_pass'], body_email['email_to'],
                           subject, body_email['body_html'])
                for mail in mails:
                    query = '''
                        UPDATE %s
                        SET "mailStatus" = '%s'
                        WHERE id = '%s';
                    ''' % ("a0_api_tracking_maintenance_table", "sent", mail[0])
                    check_query = query_database(query, conn)
                    if check_query == 0:
                        continue
                    conn.commit()
            except Exception as e:
                print(e)
                return e


def send_telegram_sub_test():
    query = '''  SELECT DISTINCT "storeChain", "id"
                 FROM %s;
            ''' % "a0_api_tracking_maintenance_table"
    cursor1 = conn.cursor()
    cursor1.execute(query)
    chains = cursor1.fetchall()
    if len(chains) == 0:
        return print("không có cửa hàng")
    # print(chains)
    for chain in chains:
        if chain[0] is None:
            continue

        # query = '''
        #             SELECT "id", "storeChain" FROM %s
        #             WHERE UPPER("storeChain") = '%s'
        #         ''' % ("a0_api_tracking_maintenance_telegram_table", chain[0].upper().replace("'", ""))
        # cursor2 = conn.cursor()
        # cursor2.execute(query)
        # receivers = cursor2.fetchall()
        # print(receivers)
        #
        # if len(receivers) == 0:
        #     continue

        query = ''' SELECT "id", "description", "storeChain", "storeID", "numberOfImage" FROM %s
                    WHERE UPPER("storeChain") = '%s' and "telegramStatus" = 'not_sent'
                            ''' % ("a0_api_tracking_maintenance_table", chain[0].upper().replace("\'", ""))
        cursor3 = conn.cursor()
        cursor3.execute(query)
        telegram_messages = cursor3.fetchall()
        if len(telegram_messages) == 0:
            continue

        contain = ""
        # for receiver in receivers:

        try:
            query = ''' SELECT "id", "telegramBot", "groupID", "storeChain" FROM %s
                                        WHERE UPPER("storeChain") = '%s'
                                                ''' % (
                "a0_api_tracking_maintenance_telegram_table", chain[0].upper().replace("\'", ""))
            cursor4 = conn.cursor()
            cursor4.execute(query)
            telegram_bot = cursor4.fetchall()
            print(len(telegram_bot))
            if len(telegram_bot) == 0:
                continue
            for bot in telegram_bot:
                contain = ""
                for telegram_message in telegram_messages:

                    if telegram_message[1] is None:
                        description = ""
                    else:
                        description = telegram_message[1].rstrip()

                    api_send = f'{telegram_contain["domain"]}{telegram_contain["endpoint_image"]}?imageID={telegram_message[0]}'

                    if int(telegram_message[4]) > 0:
                        contain = f"{contain}🆔 {telegram_message[0]} | {telegram_message[2]} | {telegram_message[3]} | {description}| [Link Hình]({api_send})\n"
                    else:
                        contain = f"{contain}🆔 {telegram_message[0]} | {telegram_message[2]} | {telegram_message[3]} | {description}| \n"

                body_email = {
                    'subject': f"[{bot[0]}] {telegram_contain['subject']}".upper(),
                    'body_html': f'{contain}',
                }
                asyncio.run(send_message(bot[1], bot[2], body_email['body_html']))
            for telegram_message in telegram_messages:
                query = '''
                        UPDATE %s
                        SET "telegramStatus" = '%s'
                        WHERE id = '%s';
                    ''' % ("a0_api_tracking_maintenance_table", "sent", telegram_message[0])
                cursor4 = conn.cursor()
                cursor4.execute(query)
                conn.commit()
        except Exception as e:
            print(f"MS001: Đang thực hiện bắt lỗi gửi tin nhắn bị lặp lại: {e}")
            continue


def send_telegram_sub():
    query = '''  SELECT DISTINCT "storeChain", "id"
                 FROM %s;
            ''' % "a0_api_tracking_maintenance_table"
    chains = query_fetchall(query, conn)
    if chains == 0:
        return print("Lỗi")

    if len(chains) == 0:
        return print("không có cửa hàng")
    for chain in chains:
        if chain[0] is None:
            continue

        query = ''' SELECT "id", "description", "storeChain", "storeID", "numberOfImage" FROM %s
                    WHERE UPPER("storeChain") = '%s' and "telegramStatus" = 'not_sent'
                            ''' % ("a0_api_tracking_maintenance_table", chain[0].upper().replace("\'", ""))
        telegram_messages = query_fetchall(query, conn)
        if telegram_messages == 0:
            continue

        if len(telegram_messages) == 0:
            continue

        contain = ""
        for telegram_message in telegram_messages:

            if telegram_message[1] is None:
                description = ""
            else:
                description = telegram_message[1].rstrip()

            api_send = f'{telegram_contain["domain"]}{telegram_contain["endpoint_image"]}?imageID={telegram_message[0]}'

            if int(telegram_message[4]) > 0:
                contain = f"{contain}🆔 {telegram_message[0]} | {telegram_message[2]} | {telegram_message[3]} | {description}| [Link Hình]({api_send})\n"
            else:
                contain = f"{contain}🆔 {telegram_message[0]} | {telegram_message[2]} | {telegram_message[3]} | {description}| \n"
        # for receiver in receivers:

        query = ''' SELECT "id", "telegramBot", "groupID", "storeChain" FROM %s
                                        WHERE UPPER("storeChain") = '%s'
                                                ''' % (
            "a0_api_tracking_maintenance_telegram_table", chain[0].upper().replace("\'", ""))
        telegram_bot = query_fetchall(query, conn)
        if telegram_bot == 0:
            continue

        if len(telegram_bot) == 0:
            continue
        for bot in telegram_bot:
            body_email = {
                'subject': f"[{bot[0]}] {telegram_contain['subject']}".upper(),
                'body_html': f'{contain}',
            }

            except_e = asyncio.run(send_message(bot[1], bot[2], body_email['body_html']))

        for telegram_message in telegram_messages:
            query = '''
                        UPDATE %s
                        SET "telegramStatus" = '%s'
                        WHERE id = '%s';
                    ''' % ("a0_api_tracking_maintenance_table", "sent", telegram_message[0])
            query_database(query, conn)
            conn.commit()


def send_email_final():
    while True:
        time.sleep(int(email_contain['time_delay']))
        send_email_sub()
        print("Hoàn thành gửi mail !!!")


def send_telegram_final():
    while True:
        # time.sleep(int(telegram_contain['time_delay']))
        time.sleep(5)
        send_telegram_sub()
        print("Hoàn thành gửi tin nhắn qua telegram !!!")


def start_email_thread():
    thread = threading.Thread(target=send_email_final)
    thread.daemon = True
    thread.start()


def start_telegram_thread():
    thread = threading.Thread(target=send_telegram_final)
    thread.daemon = True
    thread.start()


start_email_thread()
start_telegram_thread()
print(int())
print(int(-6))
