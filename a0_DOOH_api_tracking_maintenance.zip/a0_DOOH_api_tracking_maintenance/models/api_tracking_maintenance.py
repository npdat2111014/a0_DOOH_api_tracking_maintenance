from odoo import models, fields, _
from datetime import datetime
from odoo.exceptions import UserError
from odoo.http import request
import base64
import zipfile
from io import BytesIO
from odoo.addons.a0_DOOH_api_tracking_maintenance.models.config import conn


class ApiTrackingMaintenanceTelegram(models.Model):
    _name = "a0.api.tracking.maintenance.telegram.table"

    storeChain = fields.Text('Store Chain')
    groupID = fields.Text('Group ID')
    telegramBot = fields.Text('Telegram Bots')


class ApiTrackingMaintenanceMail(models.Model):
    _name = "a0.api.tracking.maintenance.mail.table"

    storeChain = fields.Text('Store Chain')
    mailReceive = fields.Text('Mail người nhận')


class ApiTrackingMaintenanceZipFile(models.Model):
    _name = "a0.api.tracking.maintenance.zip.image.table"

    name = fields.Text(string="Name of file")
    zipImage = fields.Binary(string="Image Zip File", widget="image")
    timeSave = fields.Datetime('Time Save Zip File')

    def action_download_zip(self):
        self.ensure_one()

        if not self.zipImage:
            raise UserError("No ZIP image available to download.")

        zip_data = base64.b64decode(self.zipImage)
        filename = f"images_{self.id}.zip"

        # Return an HTTP response with the file to download
        response = request.make_response(zip_data, headers=[
            ('Content-Type', 'application/zip'),
            ('Content-Disposition', f'attachment; filename="{filename}"'),
        ])
        return response


class ApiTrackingMaintenanceContainer(models.Model):
    _name = "a0.api.tracking.maintenance.container.table"
    _description = "API MAINTENANCE Container Table"

    imageDisplay = fields.Binary(string="Image", widget="image")
    imageType = fields.Text(string="Image Type")
    my_model_id = fields.Many2one('a0.api.tracking.maintenance.table', string="Image container", widget="image")


class ApiTrackingMaintenance(models.Model):
    _name = f"a0.api.tracking.maintenance.table"
    _description = "API MAINTENANCE Table"

    storeChain = fields.Text('Store Chain')
    storeID = fields.Text('Store ID')
    description = fields.Text('Description')
    numberOfImage = fields.Integer('Number of Image')
    imageDisplay = fields.One2many('a0.api.tracking.maintenance.container.table', 'my_model_id', string="Images")

    status = fields.Selection([
        ('not_completed', 'Not Considered '),
        ('completed', 'Approved'),
        ('cancelled', 'Cancelled'),
    ], string='Report Status', default='not_completed')
    reportedDate = fields.Datetime('Reported Date')
    resolutionDate = fields.Datetime('Resolution Date')
    search_view_id = fields.Many2one('ir.ui.view', string='Search View', help='Search view for this model')
    file_path = fields.Char('File Path')
    mailStatus = fields.Selection([
        ('not_sent', 'Not Sent'),
        ('sent', 'Sent'),
    ], string='Trạng thái gửi mail', default='not_sent')
    telegramStatus = fields.Selection([
        ('not_sent', 'Not Sent'),
        ('sent', 'Sent'),
    ], string='Trạng thái gửi telegram', default='not_sent')

    def unlink(self):
        images_to_delete = self.mapped('imageDisplay')
        images_to_delete.unlink()
        return super(ApiTrackingMaintenance, self).unlink()

    def btn_finish(self):
        if self.status == "completed" or self.status == "cancelled":
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Success'),
                    'message': "there is somnething wrong here !!!",
                    'type': 'warning',  # Loại thông báo (success, warning, danger)
                }}
        _conn = conn.cursor()
        _conn.execute('''
                          UPDATE %s
                          SET status = '%s', "resolutionDate" = '%s'
                          WHERE id = '%s';
                                    ''' % (
            f"a0_api_tracking_maintenance_table", "completed", datetime.now(), self.id))
        conn.commit()

        message = "Save successfully !!!"
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Success'),
                'message': message,
                'type': 'success',  # Loại thông báo (success, warning, danger)
            }}

    def btn_return(self):
        _conn1 = conn.cursor()
        _conn1.execute('''
             SELECT *
             FROM %s
             WHERE id = '%s';
                    ''' % (
            f"a0_api_tracking_maintenance_table", self.id))
        result = _conn1.fetchone()
        action = self.env.ref('a0_DOOH_api_tracking_maintenance.action_api_tracking_maintenance').sudo().read()[0]
        action['domain'] = [(1, '=', 1)]
        return action

    def btn_skip(self):
        if self.status == "completed" or self.status == "cancelled":
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Success'),
                    'message': "there is somnething wrong here !!!",
                    'type': 'warning',  # Loại thông báo (success, warning, danger)
                }}
        _conn = conn.cursor()
        _conn.execute('''
                          UPDATE %s
                          SET status = '%s', "resolutionDate" = '%s'
                          WHERE id = '%s';
                                    ''' % (
            f"a0_api_tracking_maintenance_table", "cancelled", datetime.now(), self.id))
        conn.commit()
        message = "Save successfully !!!"
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Success'),
                'message': message,
                'type': 'success',  # Loại thông báo (success, warning, danger)
            }}

    def action_download_images(self):
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/binary/download_images?model=a0.api.tracking.maintenance.table&ids=%s' % (
                ','.join(map(str, self.ids))),
            'target': 'new',
            'download': True,
        }

    def save_image_to_path(self):
        model = "a0.api.tracking.maintenance.table"
        ids = ','.join(map(str, self.ids))
        ids = [int(id) for id in ids.split(',')]
        records = request.env[model].browse(ids)

        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
            for record in records:
                for container in record.imageDisplay:
                    if container.imageDisplay:
                        image_data = base64.b64decode(container.imageDisplay)
                        mimetype = container.imageType.replace('image/', '')
                        zip_file.writestr(f'{record.storeID}_{container.id}.{mimetype}', image_data)
        zip_image_table = self.env['a0.api.tracking.maintenance.zip.image.table'].create({
            'zipImage': base64.b64encode(zip_buffer.getvalue()),
            'timeSave': datetime.now()})



