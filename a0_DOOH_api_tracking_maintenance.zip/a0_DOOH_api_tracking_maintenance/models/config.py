import psycopg2

# server_config = {
#     'dbname': "odoo17",
#     'user': "odoo17",
#     'password': "Prowtech@qwertyuiop",
#     'host': "localhost",
#     'port': "5432"
# }
server_config = {
    'dbname': "DOOH_management_erp",
    'user': "openpg",
    'password': "openpgpwd",
    'host': "localhost",
    'port': "5432"
}

conn = psycopg2.connect(
    dbname=server_config['dbname'],
    user=server_config['user'],
    password=server_config['password'],
    host=server_config['host'],
    port=server_config['port']
)

email_contain = {
    'sender_email': "dat.nguyen14012003@hcmut.edu.vn",
    'sender_password': "zibn gvlo svke ysil",
    'recipient_email': "phuocdat1401001@gmail.com",
    'subject': "Email báo cáo sự cố của Prowtech",
    'body': "Chúng tôi có thông báo mới gửi đến bạn:",
    'time_delay': 10,
    'domain': 'http://192.168.1.13:8069/',
    'endpoint_image': 'images'
}

telegram_contain = {
    'sender_email': "dat.nguyen14012003@hcmut.edu.vn",
    'sender_password': "zibn gvlo svke ysil",
    'recipient_email': "phuocdat1401001@gmail.com",
    'subject': "Email báo cáo sự cố của Prowtech",
    'body': "Chúng tôi có thông báo mới gửi đến bạn:",
    'time_delay': 5,
    'domain': 'http://192.168.1.40:8069/',
    'endpoint_image': 'images'
}



