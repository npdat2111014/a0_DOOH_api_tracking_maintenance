import os


def read_html_file():
    addons_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    file_path = os.path.join(addons_path, 'a0_DOOH_api_tracking_maintenance', 'views', 'email_template.xml')
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()
        return file_content
    except FileNotFoundError:
        return 0
    except Exception as e:
        return 0


def email_carry(_contain):
    email = read_html_file()
    if email == 0:
        return 0
    final_email = email.replace("contain", f"{_contain}")

    return final_email


def query_database(_query, _conn):
    try:
        cursor = _conn.cursor()
        cursor.execute(_query)
        return 1
    except Exception:
        return 0


def query_fetchall(_query, _conn):
    try:
        cursor = _conn.cursor()
        cursor.execute(_query)
        return cursor.fetchall()
    except Exception:
        return 0
