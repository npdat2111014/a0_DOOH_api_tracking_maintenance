import requests
from telegram import Bot
import pytz
from datetime import datetime
from aiogram import Bot

async def send_message(_bot_token, _group_chat_id, body):
    try:
        bot = Bot(token=_bot_token)
        group_chat_id = _group_chat_id

        body = body.replace("_", "\\_").replace("*", "\\*").replace("'", "\\'")
        now = datetime.now()
        utc_time = now.astimezone(pytz.utc)
        vietnam_tz = pytz.timezone('Asia/Ho_Chi_Minh')
        vietnam_time = utc_time.astimezone(vietnam_tz)
        formatted_vietnam_time = vietnam_time.strftime("%Y-%m-%d %H:%M")
        message = f"{body}🕙: {formatted_vietnam_time}"
        await bot.send_message(chat_id=group_chat_id, text=message, parse_mode='Markdown')
        return 1
    except Exception:
        return 0



def verify_token(token):
    url = f'https://api.telegram.org/bot{token}/getMe'
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        if data["ok"] is True:
            return True
        else:
            return False
    else:
        return False
